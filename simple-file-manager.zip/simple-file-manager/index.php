<?php
require_once "initialize.php";
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<link rel="stylesheet" type="text/css" href="css/roboto.css">
	<link rel="stylesheet" type="text/css" href="css/manager-style.css">
	<script src="vendor/jquery/jquery-3.4.1.min.js"></script>
	<script src="js/dataTable.js"></script>
	<script src="js/main.js"></script>
</head>
<body>
	<div class="main-frame">
		<div class="app-header">
			<h4>File Manager System</h4>
			<a href="admin/index.php" style="font-size: 15px;position: absolute;top: 0px;right: 10px;" target="_blank">Setting</a>
		</div>
		<div class="topbar">
			<div id="breadcrumb">&nbsp;</div>
			<div class="right-btn">
				<input type="text" name="search" placeholder="Search file/folder" class="searchfolderdir" style="margin-right: 5px;">
				<?php
				if($managerEssential->createFolder == 1){
				?>
				<button type="button" onclick="openPopUp('fileupload')" class="addFile" style="margin-right: 5px;">
				Add File
				</button>
				<?php
				}
				if($managerEssential->createFolder == 1){
				?>
				<button type="button" onclick="openPopUp('createFolder')">
				Create Folder
				</button>
				<?php
				}
				?>
			</div>
		</div>
		<div class="errors">

		</div>
		<table id="dataTable">
			<thead>
				<tr>
					<th>Name</th>
					<th>Type</th>
					<th>Size</th>
					<th>Modified</th>
				</tr>
			</thead>
			<tbody id="dataList">
			</tbody>
		</table>
	</div>
	<?php
	if($managerEssential->createFolder == 1){
	?>
		<div class="fileupload popup" style="display: none;">
			<div class="popup-inner">
				<div class="popup-close" onclick="closePopUp()">
					x
				</div>
				<div id="file_drop_target">
					Drag Files Here To Upload
					<b>or</b>
					<input type="file" multiple />
				</div>
			</div>
		</div>
	<?php
	}
	if($managerEssential->createFolder == 1){
	?>
	<div class="createFolder popup" style="display: none;">
		<div class="popup-inner">
			<div class="popup-close" onclick="closePopUp()">
				x
			</div>
			<form action="initialize.php" method="post" id="mkdir" />
				<label for="dirname">Create New Folder</label>
				<input id="dirname" type="text" name="name" value="" />
				<button type="submit">Create</button>
			</form>
		</div>
	</div>
	<?php
	}
	?>
	<div class="rename popup" style="display: none;">
		<div class="popup-inner">
			<div class="popup-close" onclick="closePopUp()">
				x
			</div>
			<form action="initialize.php" method="post" id="rename"/>
				<label for="dirname">Rename File/Folder</label>
				<input type="hidden" class="fileName" name="fileName" value="">
				<input id="dirname" type="text" name="name" value="" />
				<button type="submit">Update</button>
			</form>
		</div>
	</div>
	<div class="copy popup" style="display: none;">
		<div class="popup-inner">
			<div class="popup-close" onclick="closePopUp()">
				x
			</div>
			<form action="initialize.php" method="post" id="copy"/>
				<label for="dirname">Copy File/Folder</label>
				<input type="hidden" class="fileName" name="fileName" value="">
				File Manager/<input id="dirname" type="text" name="name" value="" />
				<button type="submit">Copy</button>
			</form>
		</div>
	</div>
	<div class="move popup" style="display: none;">
		<div class="popup-inner">
			<div class="popup-close" onclick="closePopUp()">
				x
			</div>
			<form action="initialize.php" method="post" id="move"/>
				<label for="dirname">Move File/Folder</label>
				<input type="hidden" class="fileName" name="fileName" value="">
				File Manager/<input id="dirname" type="text" name="name" value="" />
				<button type="submit">Move</button>
			</form>
		</div>
	</div>

</body>
</html>