<?php
ob_start();
session_start();
ob_flush();
$urlArr = explode("/admin", trim($_SERVER['REQUEST_URI'], '/'));
if(!defined('directory')):
      define('directory', $urlArr[0].'/admin');
endif;

$urlArrAnother = explode("/admin", dirname($_SERVER['SCRIPT_FILENAME']));

use Filemanager\activepage;
use Filemanager\auth;
use Filemanager\Essential;

$page['page'] = isset($_GET['page']) ? $_GET['page'] : '';
$pageOpt = new activepage($page);
$auth = new auth();
$managerEssential = new Essential($urlArrAnother[0]);

/**
**Intialize App Setting setting.
**/

$pageOpt->pageTree = array(
      'index'             =>  array('configure'),
      'help'              =>  array('need-help'),
      'login'             =>  array('')
);
$pageOpt->pageTitle = array(
      'index'           =>  array('configure' => 'App Configure'),
      'help'            =>  array('need-help' => 'Help'),
      'login'           =>  array('login' => 'Login')
);

/**
**Intialize themes setting end.
**/

if(isset($_GET['logout'])):
	if($_GET['logout'] == 1):
		$auth->forceLogout();
	endif;
endif;
?>