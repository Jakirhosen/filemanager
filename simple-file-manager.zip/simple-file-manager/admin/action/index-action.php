<?php
require_once '../../vendor/autoload.php';
require_once '../ini.php';
if(!$auth->authUser()):
    $auth->loginPageRedirect();
else:
    if(isset($_POST['formName'])):
        if($_POST['formName'] == 'configSetup'):
            unset($_POST['formName']);
            $managerEssential->setConfig($_POST);
            echo  json_encode(array('status' => 'success'));
        else:
            echo  json_encode(array('status' => 'failed'));
        endif;
    endif;
endif;