<?php
require_once '../../vendor/autoload.php';
require_once('../ini.php');

if(isset($_POST['username']) && isset($_POST['password'])):
  $username = $_POST['username'];
  $password = md5($_POST['password']);
  $status = $auth->userVerify($username, $password);
  if($status == 'success'):
    $user = array(
         'loginStats' => 'success',
         'redirecturl' => $pageOpt->getRequestedPage()
     );
     echo json_encode($user);
  elseif($status == 'failed'):
    $user = array(
         'loginStats' => 'failed',
         'errorval' => 'not registered'
     );
     echo json_encode($user);
  endif;
endif;

?>