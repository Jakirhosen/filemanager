<div class="navview-pane" style="background: #103642;">
    <div class="d-flex flex-align-center close" style="background-color: #fff;">
        <button class="pull-button m-0 ribbed-darkTeal">
        <span class="mif-menu fg-white" style="font-size: 28px; width: 28px; height: 28px; line-height: 28px;"></span>
        </button>
        <h2 class="fg-light company-text" style="margin: 0 auto !important; text-align: center; font-size: 22.5px;"> <img src="images/file-manager.png" style="width: 150px;border-radius: 20px 0px;"></h2>
    </div>
    
    <ul class="navview-menu" id="side-menu" style="background: #103642;">
        <li class="item-header text-center ribbed-darkTeal fg-white text-bold" style="margin-left: -8px;"><span class="mif-navigation"></span> Navigation</li>
        <li class="border-bottom bd-darkTeal">
            <a href="index.php" class="configure">
                <span class="icon"><span class="mif-cogs"></span></span>
                <span class="caption">Comnfigure</span>
            </a>
        </li>
        <!-- <li class="border-bottom bd-darkTeal">
            <a href="help.php?page=need-help" class="need-help">
                <span class="icon"><span class="mif-help"></span></span>
                <span class="caption">Help</span>
            </a>
        </li>     -->                 
    </ul>
    <div class="w-100 text-center text-small data-box p-2">
        <div><img src="images/beta.png" style="width: 55px;background: #fff;border-radius: 13px; transform: rotate(-27deg);"></div>
    </div>

    <div class="w-100 text-center text-small data-box p-2 border-top bd-grayMouse" style="position: absolute; bottom: 0">
        <div>Developed by <a href="https://www.linkedin.com/in/md-jakir-hosen-6295b3158/" target="_blank">Md. Jakir Hosen</a></div>
    </div>
</div>