<script src="../vendor/jquery/jquery-3.4.1.min.js"></script>
<script src="../vendor/metro4/js/metro.min.js"></script>
<script src="js/main.js"></script>
