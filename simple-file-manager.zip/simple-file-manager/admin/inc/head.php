<?php require_once('ini.php'); ?>
<html lang="en">
<head>
    <!-- Required meta tags -->
    
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="metro4:init" content="true">
    <link rel="icon" type="image/x-icon" href="favicon-filemanager.ico" />
    <!-- Metro 4 -->
    <link rel="stylesheet" href="../vendor/metro4/css/metro-all.min.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/custom-style.css">

    <title><?=$pageOpt->appTitle('-');?>File Manager System</title>    
</head>