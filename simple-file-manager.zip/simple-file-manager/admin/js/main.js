$(function() {
if($('.content-title-big').length > 0){
   var getData = $('.content-title-big').data('group');
   var getMenu = $('.content-title-big').data('page');
   $('.'+getData).css('display', 'block');
   $('.'+getData+'s').addClass('active-toggle active-control rotateicon');
   $('.'+getData+'s').parent('li').addClass('active-container');
  // $('.'+getData+'s').addClass('bg-darkCrimson');
   $('.'+getMenu).css({'background': '#006d77', 'font-weight': 'bold'});
  }

  $('.navview-menu .dropdown-toggle').on('click', function(e){
  	 e.preventDefault();
  	 //$(this).removeClass('rotateicon');
     if($(this).hasClass('rotateicon') == true){
        $(this).removeClass('rotateicon');
     }else{
     	$('.dropdown-toggle').removeClass('rotateicon');
     	$(this).addClass('rotateicon');
     }
  });

  $('.login-form').on('submit', function(event){
    event.preventDefault();
    var form = $(this);
    var error = [];
    $('.invalid_feedback').css('display', 'none');
    form.find('.faildlogin').empty();
    form.find('input').each(function(index, el) {
      if($(this).val().length == 0){
        error.push('1');
        $(this).closest('.form-group').find('.invalid_feedback').css('display', 'block');
      }
    });
    if(error.length == 0){
      preloaderStart();
      var formData = form.serializeArray();
      $.ajax({
        type: 'POST',
        url: 'action/login-action.php',
        dataType : 'json',
        data: formData,
        success: function(getloginresponse){
          if(getloginresponse['loginStats'] == 'success'){
            // alert(getloginresponse['redirecturl']);
            window.location.href = getloginresponse['redirecturl']; 
          }else if(getloginresponse['loginStats'] == 'failed'){
            preloaderClose();
            form.find('.faildlogin').append('<p style="padding: 10px;">Invalid Username or Password!</p>');
            form.addClass("ani-ring");
            setTimeout(function(){
              form.removeClass("ani-ring");
            }, 2000);   
          }
        }
      });
    }else{
      form.addClass("ani-ring");
      setTimeout(function(){
        form.removeClass("ani-ring");
      }, 2000); 
    }
  });

  $('.save-configureData').on('click', function(evt){
    var deleteF = 0;
    if($('.allowDelete input').is(':checked')){
      deleteF = 1;
    }
    var upload = 0;
    if($('.allowUpload input').is(':checked')){
      upload = 1;
    }
    var folderCreate = 0;
    if($('.allowCreateFolder input').is(':checked')){
      folderCreate = 1;
    }
    var link = 0;
    if($('.allowLink input').is(':checked')){
      link = 1;
    }
    var folder = 0;
    if($('.allowFolder input').is(':checked')){
      folder = 1;
    }
    var uploadSize = $('.uploadSize input').val();
    var extention = $('.hideExt input').val();
    var allowedFileUpload = $('.uploadNotAllow input').val();
    $.ajax({
        type: 'POST',
        url: 'action/index-action.php',
        dataType : 'json',
        data: {'deleteF' : deleteF, 'upload' : upload, 'folderCreate' : folderCreate, 'link' : link, 'folder' : folder, 'uploadSize' : uploadSize, 'hideExt' : extention, 'allowedFileUpload' : allowedFileUpload, 'formName' : 'configSetup'},
        success: function(getresponse){
          if(getresponse['status'] == 'success'){
            window.location.reload();
          }
        }
      });


  });

});

function preloaderClose(){
  $('.preloader').css('display', 'none');
}
function preloaderStart(){
  $('.preloader').css('display', 'block');
}