<!DOCTYPE html>
<?php
require_once '../vendor/autoload.php';
include_once('inc/head.php');
if(!$auth->authUser()):
    $pageOpt->deleteRequestedPage();
    $pageOpt->setRequestedPage($_SERVER['REQUEST_URI']);
    $auth->loginPageRedirect();
else:
$userid = $auth->loggedUserId();
?>
<body class="m4-cloak h-vh-100">
    <div class="preloader" style="display: none; position: absolute;z-index: 1035;width: 100%;height: 100vh;top: 0;background: rgba(255, 255, 255, 0.8); left: 0;">
        <div data-role="activity" data-type="square" data-style="color" style="position: relative;top: 50%; left: 50%;"></div>
    </div>
    <div data-role="navview" data-toggle="#paneToggle" data-expand="xxl" data-compact="xl" data-active-state="true">
        <?php include_once('inc/navigation.php'); ?>
        <div class="navview-content h-100">
            <?php include_once('inc/topbar.php'); ?>
            <div class="content-inner h-100" style="overflow-y: auto">
                <div class="row border-bottom bd-lightGray pl-1 mr-1 ribbed-lightGray" style="margin-left: 0px;">
                    <div class="cell-md-4">
                        <h4 class="dashboard-section-title text-center text-left-md w-100 content-title-big" data-group="index" data-page="configure" style="font-size: 1.2rem; line-height: 22px; font-weight: bold; text-shadow: 1px 1px 2px #fff;"><span class="icon"><span class="mif-cogs"></span></span> Configure</h4>
                    </div>
                </div>
                <div class="d-flex flex-justify-center">
                    <div class="cell-lg-12">
                        <div data-role="panel" data-title-caption="Control Access of File Manager" data-collapsible="false" data-title-icon="<span class='mif-cog'></span>">
                            <div class="ml-1 mr-1">
                                <div class="row">
                                    <?php
                                    if($managerEssential->delete == 1){
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Delete (Folder/File)</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowDelete" checked data-material="true" data-caption="Allowed">
                                        </div>
                                    </div>
                                    <?php
                                    }else{
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Delete (Folder/File)</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowDelete"  data-material="true" data-caption="Not Allow">
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    if($managerEssential->upload == 1){
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Upload File</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowUpload" checked data-material="true" data-caption="Allowed">
                                        </div>
                                    </div>
                                    <?php
                                    }else{
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Upload File</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowUpload"  data-material="true" data-caption="Not Allow">
                                        </div>
                                    </div>
                                    <?php    
                                    }
                                    if($managerEssential->createFolder == 1){
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Create Folder</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowCreateFolder" checked data-material="true" data-caption="Allowed">
                                        </div>
                                    </div>
                                    <?php
                                    }else{
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Create Folder</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowCreateFolder" data-material="true" data-caption="Not Allow">
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    if($managerEssential->allowLink == 1){
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">File Direct Link</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowLink" checked data-material="true" data-caption="Allowed">
                                        </div>
                                    </div>
                                    <?php
                                    }else{
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">File Direct Link</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowLink"  data-material="true" data-caption="Not Allow">
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    if($managerEssential->showFolder == 1){
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Show Folder</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowFolder" checked data-material="true" data-caption="Allowed">
                                        </div>
                                    </div>
                                    <?php
                                    }else{
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Show Folder</label><br>
                                            <input type="checkbox" data-role="switch" data-cls-switch="allowFolder" data-material="true" data-caption="Not Allow">
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Max Allowed File Size To Upload</label>
                                            <input type="text" data-role="input" class="uploadSize" value="<?=round(($managerEssential->managerAllowedFileSize/1024)/1024)?>" data-append="MB">
                                        </div>
                                    </div>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Hide Extension (Ex. php,json,html)</label>
                                            <input type="text" data-role="input" class="hideExt" value="<?=implode(',', $managerEssential->hiddenFile)?>">
                                        </div>
                                    </div>
                                    <div class="cell-lg-12">
                                        <div class="form-group">
                                            <label class="text-bold">Not Allowed File To Upload (Ex. php,json,html)</label>
                                            <input type="text" data-role="input" class="uploadNotAllow" value="<?=implode(',', $managerEssential->allowedUploadFile)?>">
                                        </div>
                                    </div>
                                    <div class="cell-lg-12 flex-justify-between">
                                        <button class="image-button success save-configureData">
                                            <span class="mif-done_all"></span>
                                            <span class="caption">Save</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    include_once('inc/footer.php');
    ?>
</body>
<?php
endif;
?>
</html>