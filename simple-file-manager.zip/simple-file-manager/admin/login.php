<!DOCTYPE html>
<?php
require_once '../vendor/autoload.php';
include_once('inc/head.php');
if($auth->authUser()):
    $url = $pageOpt->getRequestedPage();
    header("location: $url");
else:
?>
    <body class="m4-cloak" style="background: linear-gradient(#3fa3ac,#fff) !important;">
        <div class="preloader" style="display: none; position: absolute;z-index: 1035;width: 100%;height: 100vh;top: 0;background: rgba(255, 255, 255, 0.8); left: 0;">
            <div data-role="activity" data-type="square" data-style="color" style="position: relative;top: 50%; left: 50%;"></div>
        </div>
        <div class="h-vh-100 d-flex flex-justify-center flex-align-center">
            <div class="login-box bg-white">
                <form class="bg-white p-4 login-form" method="POST" action="">
                    <img src="images/file-manager.png" class="place-right" style="width: 150px;margin-top: -14px;margin-right: -13px;">
                    <h1 class="mb-0">Login</h1>
                    <div class="fg-teal mb-3 mt-2" style="font-size: 14px;">File Manager System</div>
                    <div class="faildlogin mb-3 mt-2" style="color: #721c24; background-color: #f8d7da; border-color: #f5c6cb; font-size: 14px;">
                        
                    </div>
                    <div class="form-group">
                        <input type="text" data-role="input" placeholder="Enter Your Username" name='username' data-append="<span class='mif-user'>" data-validate="required" value="admin">
                        <span class="invalid_feedback">Enter your valid Username</span>
                    </div>
                    <div class="form-group">
                        <input type="password" data-role="input" name="password" placeholder="Enter Your Password" data-append="<span class='mif-key'>" data-validate="required" value="admin@123">
                        <span class="invalid_feedback">Enter your valid password</span>
                    </div>
                    <div class="form-group d-flex flex-align-center flex-justify-between">
                        <div></div>
                        <button class="image-button outline dark icon-right" type="submit">
                        <span class="mif-settings-power icon"></span>
                        <span class="caption">Login</span>
                        </button>
                    </div>
                    <div class="form-group d-flex flex-align-center flex-justify-between">
                        <a href="<?=$_SERVER['REQUEST_SCHEME'].'://'.$_SERVER['HTTP_HOST'].'/'.$urlArr[0]?>">Browse Filemanager</a>
                    </div>
                </form>
                <footer class="text-center pt-5 pb-5 bg-white">
                    <div style="position: relative; color: #868686; font-family: arial; font-size: 13px;">Developed by <a href="https://www.linkedin.com/in/md-jakir-hosen-6295b3158/" target="_blank">Md. Jakir Hosen</a></div>
                </footer>
            </div>
        </div>
        <?php include_once('inc/footer.php'); ?>
    </body>
<?php 
endif;
?>
</html>