<?php
require_once 'vendor/autoload.php';

use Filemanager\Essential;
use Filemanager\FileManager;

$managerEssential = new Essential(dirname($_SERVER['SCRIPT_FILENAME']));

$managerEssential->setAppLocal("en_US.UTF-8");

$tmpDir = $managerEssential->fileDirectory;

if(DIRECTORY_SEPARATOR === '\\'){
	$tmpDir = str_replace('/',DIRECTORY_SEPARATOR, $tmpDir);
}

$file = (isset($_REQUEST['file'])) ? "FileManager/".$_REQUEST['file'] : 'FileManager';


$tmp = $managerEssential->getAbsolutePath($tmpDir . '/' .(isset($_REQUEST['file']) ? $_REQUEST['file'] : ''));

$fileManager = new FileManager($file);

if($tmp === false){
	$fileManager->errorWithSatusfunction(200,'File or Directory Not Found!');
	exit;
}
if(substr($tmp, 0, strlen($tmpDir)) !== $tmpDir){
	$fileManager->errorWithSatusfunction(200, "Access Forbidden!");
	exit;
}
if(strpos($file, DIRECTORY_SEPARATOR) === 0){
	$fileManager->errorWithSatusfunction(200, "Access Forbidden");
	exit;
}

if(isset($_POST['do'])){
	if ($_POST['do'] == 'delete') {
		$fileManager->delete($managerEssential->delete);
		exit;
	}elseif($_POST['do'] == 'mkdir') {
		$dir = $_POST['name'];
		$dir = str_replace('/', '', $dir);
		if(substr($dir, 0, 2) !== '..'){
			if(is_dir($file."/".$dir)){
				$fileManager->errorWithSatusfunction(200, "Directory name exists!");
			}else{
				$fileManager->createDirectory($managerEssential->createFolder, $dir);
			}
		}else{
			$fileManager->errorWithSatusfunction(200, "Invalid directory name!");
		}
		exit;
	}elseif($_POST['do'] == 'rename') {
		$rename = $_POST['name'];
		$rename = str_replace('/', '', $rename);
		$path = str_replace($file, '', $_POST['filepath']);
		if(substr($rename, 0, 2) !== '..'){
			if(is_dir($file.$path)){
				if(is_dir($file.$fileManager->cleanSpecialChar($rename))){
					$fileManager->errorWithSatusfunction(200, "Folder name exists!");
				}else{
					rename($file.$path, $file.$fileManager->cleanSpecialChar($rename));
					echo json_encode(['success' => true]);
				}
			}else{
				if(file_exists($file.$rename)){
					$fileManager->errorWithSatusfunction(200, "File name exists!");
				}else{
					$extention = pathinfo($_POST['filepath']);
					rename($file.$path, $file.$fileManager->cleanSpecialChar($rename).'.'.$extention['extension']);
					echo json_encode(['success' => true]);
				}	
			}
		}else{
			$fileManager->errorWithSatusfunction(200, "Invalid File/Folder name!");
		}
		exit;
	}elseif($_POST['do'] == 'copy') {
		$fileManager->errorWithSatusfunction(200, "This portion under developed!");
		// $copyPath = trim(str_replace('/', '\\',$_POST['name']), '\\');
		// $path = str_replace($file, '', $_POST['filepath']);
		// // echo $managerEssential->getAbsolutePath($tmpDir).'\\'.$copyPath;
		// if(is_dir($managerEssential->getAbsolutePath($tmpDir).'\\'.$copyPath)){
		// 	if(is_dir($file.$path)){
		// 		$fileManager->customCopy($file.$path, $managerEssential->getAbsolutePath($tmpDir).'\\'.$copyPath);
		// 	}else{
		// 		copy($file.$path, "FileManager/".$copyPath.'/'.$path);
		// 	}
		// 	echo json_encode(['success' => true]);
		// }else{
		// 	$fileManager->errorWithSatusfunction(200, "Copy directory not found!");
		// }
		exit;
	}elseif($_POST['do'] == 'move') {
		$fileManager->errorWithSatusfunction(200, "This portion under developed!");
		// $movePath = $_POST['name'];
		// $path = str_replace($file, '', $_POST['filepath']);
		// if(is_dir($managerEssential->getAbsolutePath($tmpDir).'/'.$movePath)){

		// }else{
		// 	$fileManager->errorWithSatusfunction(200, "Move directory not found!");
		// }

		// if(substr($rename, 0, 2) !== '..'){
		// 	if(is_dir($file.$path)){
		// 		if(is_dir($file.$fileManager->cleanSpecialChar($rename))){
		// 			$fileManager->errorWithSatusfunction(200, "Folder name exists!");
		// 		}else{
		// 			rename($file.$path, $file.$fileManager->cleanSpecialChar($rename));
		// 			echo json_encode(['success' => true]);
		// 		}
		// 	}else{
		// 		if(file_exists($file.$rename)){
		// 			$fileManager->errorWithSatusfunction(200, "File name exists!");
		// 		}else{
		// 			$extention = pathinfo($_POST['filepath']);
		// 			rename($file.$path, $file.$fileManager->cleanSpecialChar($rename).'.'.$extention['extension']);
		// 			echo json_encode(['success' => true]);
		// 		}	
		// 	}
		// }else{
		// 	$fileManager->errorWithSatusfunction(200, "Invalid File/Folder name!");
		// }
		exit;
	}elseif ($_POST['do'] == 'upload') {
		if(file_exists($file."/".$_FILES['file_data']['name'])){
			echo json_encode(['error' => "(".$_FILES['file_data']['name'].") File name already exists in this folder!"]);
		}else{
			$fileManager->upload($managerEssential->allowedUploadFile, $_FILES);
		}
		exit;
	}
}

if(isset($_GET['do'])){
	if($_GET['do'] == 'list') {
		$fileManager->dataDraw($managerEssential->configData, trim($_GET['search']));
		exit;
	}elseif ($_GET['do'] == 'download'){
		$filename = basename($file);
		$finfo = finfo_open(FILEINFO_MIME_TYPE);
		header('Content-Type: ' . finfo_file($finfo, $file));
		header('Content-Length: '. filesize($file));
		header(sprintf('Content-Disposition: attachment; filename=%s',
			strpos('MSIE',$_SERVER['HTTP_REFERER']) ? rawurlencode($filename) : "\"$filename\"" ));
		ob_flush();
		readfile($file);
		exit;
	}
}