<?php

/**
* All essential method contain in this class.
* Author: Md Jakir Hosen. 
**/

namespace Filemanager;

class Essential
{
	
	public $managerAllowedFileSize;
	public $delete;
	public $upload;
	public $createFolder;
	public $allowLink;
	public $showFolder;
	public $hiddenFile;
	public $allowedUploadFile;
	public $fileDirectory;
	public $configData;
	private $directoryPath;
	function __construct($dirPath){
		$this->directoryPath = $dirPath;
		$this->fileDirectory = $this->directoryPath."/FileManager";
		if(file_exists($this->directoryPath."/configStorage.json")){
			$configDataRead = file_get_contents($this->getAbsolutePath($this->directoryPath."/configStorage.json"));
			$this->configData = json_decode($configDataRead, true);
		}else{
			$this->configData = array("delete" => 1, "upload" => 1, "folderCreate" => 1, "link" => 1, "folderShow" => 1, "fileNotAllowToUpload" => array("php", "html"), "hideExt" => array("php", "html"), "maxFileUploadAllow" => 5);
			$fp = fopen($this->directoryPath."/configStorage.json", "w");
			fwrite($fp, json_encode($this->configData));
			fclose($fp);
			clearstatcache();
		}
		
		if(!is_dir($this->fileDirectory) && $this->directoryPath == dirname($_SERVER['SCRIPT_FILENAME'])){
			mkdir($this->fileDirectory);
		}

		$this->managerAllowedFileSize = ($this->configData['maxFileUploadAllow']*1024)*1024;
		$this->delete = $this->configData['delete'];
		$this->upload = $this->configData['upload'];
		$this->createFolder = $this->configData['folderCreate'];
		$this->allowLink = $this->configData['link'];
		$this->showFolder = $this->configData['folderShow'];
		$this->hiddenFile = $this->configData['hideExt'];
		$this->allowedUploadFile = $this->configData['fileNotAllowToUpload'];
	}

	public function getAbsolutePath($path) {
        $path = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, $path);
        $parts = explode(DIRECTORY_SEPARATOR, $path);
        $absolutes = [];
        foreach ($parts as $part) {
            if ('.' == $part) continue;
            if ('..' == $part) {
                array_pop($absolutes);
            } else {
                $absolutes[] = $part;
            }
        }
        return implode(DIRECTORY_SEPARATOR, $absolutes);
    }

    public function setConfig(array $post){
    	$data = array("delete" => $post['deleteF'], "upload" => $post['upload'], "folderCreate" => $post['folderCreate'], "link" => $post['link'], "folderShow" => $post['folder'], "fileNotAllowToUpload" => explode(',', $post['allowedFileUpload']), "hideExt" => explode(',', $post['hideExt']), "maxFileUploadAllow" => intval($post['uploadSize']) == 0 ? 5 : $post['uploadSize']);
		$fp = fopen($this->directoryPath."/configStorage.json", "w");
		fwrite($fp, json_encode($data));
		fclose($fp);
		clearstatcache();
    }

    public function setAppLocal($param = ""){
    	if(empty($param)){
    		setlocale(LC_ALL,'en_US.UTF-8');
    	}else{
    		setlocale(LC_ALL, $param);
    	}
    }

    public function error($code, $msg) {
		http_response_code($code);
		echo json_encode(['error' => ['code'=>intval($code), 'msg' => $msg]]);
		exit;
    }

}
?>