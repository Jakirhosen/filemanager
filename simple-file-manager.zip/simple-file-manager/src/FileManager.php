<?php

/**
* Draw Manager list and contain filemanager core method.
* Author: Md Jakir Hosen. 
**/

namespace Filemanager;

class FileManager
{
	private $path;
	function __construct($filePath){
		$this->path = $filePath;
	}

	public function dataDraw(array $permission, $searchVal=''){
		if (is_dir($this->path)) {
			$result = [];
			$files = array_diff(scandir($this->path), ['.', '..']);
			foreach ($files as $entry){
				if ( !$this->hideExt($permission['hideExt'], $entry) && !$this->checkIgnored($entry, $permission['folderShow'])) {
					if(empty(trim($searchVal))){
						$i = rtrim($this->path, '/') . '/' . $entry;
						$stat = stat($i);
				        $result[] = [
				        	'mtime' => $stat['mtime'],
				        	'size' => $stat['size'],
				        	'name' => basename($i),
				        	'path' => preg_replace('@^\./@', '', $i),
				        	'is_dir' => is_dir($i),
				        	'is_readable' => is_readable($i),
				        	'is_writable' => is_writable($i),
				        	'is_executable' => is_executable($i)
				        ];
					}else{
						$i = rtrim($this->path, '/') . '/' . $entry;
						if(strpos(strtolower(basename($i)), strtolower($searchVal)) !== false){
							$stat = stat($i);
					        $result[] = [
					        	'mtime' => $stat['mtime'],
					        	'size' => $stat['size'],
					        	'name' => basename($i),
					        	'path' => preg_replace('@^\./@', '', $i),
					        	'is_dir' => is_dir($i),
					        	'is_readable' => is_readable($i),
					        	'is_writable' => is_writable($i),
					        	'is_executable' => is_executable($i)
					        ];
					    }
					}
					
			    }
			}
			echo json_encode(['success' => true, 'results' =>$result]);	
		}else{
			$this->errorWithSatusfunction(200, "Not a Directory");
		}	
	}

	protected function hideExt(array $extention, $file){
		$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
		if (in_array($ext, $extention)) {
			return true;
		}else{
			return false;
		}

	}

	protected function checkIgnored($file, $showFolder) {
		if ($file === basename(__FILE__)) {
			return true;
		}
		if (is_dir($file) && $showFolder == 0) {
			return true;
		}
		return false;
	}

	public function errorWithSatusfunction($code, $msg) {
		http_response_code($code);
		echo json_encode(['error' => ['code'=>intval($code), 'msg' => $msg]]);
	}

	public function delete($permission = 0) {
		if($permission == 1){
			if(is_dir($this->path)) {
				$files = array_diff(scandir($this->path), ['.','..']);
				foreach ($files as $file){
					unlink($this->path."/".$file);
				}
				rmdir($this->path);
			}else {
				unlink($this->path);
			}
			echo json_encode(['success' => true]);
		}else{
			$this->errorWithSatusfunction(403,"Delete permission disabled by system admin!");
		}
	}

	public function upload(array $permission, $file){
		$error = array();
		$success = array();
		$getExt = explode('.', $file['file_data']['name']);
		if(in_array(end($getExt), $permission)){
			echo json_encode(['error' => "(".$file['file_data']['name'].") File format is not allowed to upload!"]);
		}else{
			move_uploaded_file($file['file_data']['tmp_name'], $this->path.'/'.$file['file_data']['name']);
			echo json_encode(['error' => '']);	
		}
	}

	public function createDirectory($permission, $name){
		if($permission == 1){
			mkdir($this->path."/".$this->cleanSpecialChar($name));
			echo json_encode(['success' => true]);
		}else{
			$this->errorWithSatusfunction(200, "You have not permission to create directory!");
		}
	}

	 public function cleanSpecialChar($string) { 
		$string = preg_replace('/[^A-Za-z0-9\-_]/', ' ', $string);
		$string = preg_replace('/\s+/', ' ', $string); 
		return $string; 
	}

	public function customCopy($src, $dst) {
		$dir = opendir($src); 
	    @mkdir($dst); 
	    while( $file = readdir($dir) ) { 
	        if (( $file != '.' ) && ( $file != '..' )) { 
	            if ( is_dir($src . '/' . $file) ) { 
	                $this->customCopy($src . '/' . $file, $dst . '/' . $file); 
	            } 
	            else { 
	                copy($src . '/' . $file, $dst . '/' . $file); 
	            } 
	        } 
	    } 
	    closedir($dir);
	    return true;
	} 
  

	
}
?>