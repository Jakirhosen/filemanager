<?php 
/**
 * Handle user login session & permission.
 * Author: Md Jakir Hosen. 
 **/

namespace Filemanager;

class auth
{   
	private $directoryFolder;
	public function __construct()
	{
		$this->directoryFolder = directory == '/' ? '/' : '/'.directory.'/';
	}

	public function userVerify($username, $password){
		$usernameSet = 'admin';
		$passwordSet = md5('admin@123');
		if($usernameSet == $username && $passwordSet == $password){
			$_SESSION['fileManagerSystemAdmin'] = 1; 
			return 'success';
		}else{
			return 'failed';
		}
		
	}

	public function authUser(){
		if(isset($_SESSION['fileManagerSystemAdmin'])){
			if(!empty($_SESSION['fileManagerSystemAdmin'])){
			    return true;
		    }else{
		    	return false;
		    }
		}else{
			return false;
		}
	}

	public function loginPageRedirect(){
		$loginUrl = "http://".$_SERVER['HTTP_HOST'].$this->directoryFolder."login.php";
		header("location: $loginUrl");
	}

	public function loggedUser(){
		$userInfo = array();
		$userInfo['username'] = 'admin';
		$userInfo['fullname'] = 'Md. Jakir Hosen';
		$userInfo['image'] = 'images/jek_vorobey.jpg';
		$userInfo['role'] = 'Admin';
		return $userInfo;
	}

	public function loggedUserId(){
		if($this->authUser()){
			return $_SESSION['fileManagerSystemAdmin'];
		}else{
			return false;
		}
	}

	public function forceLogout(){
		setcookie('accredirectpage', '', ['expires' => time() - (3600), 'path' => '$this->directoryFolder', 'httponly' => true, 'samesite' => 'Strict']);
		session_destroy();
		$this->loginPageRedirect();
	}

}