$(function(){
	var maxAllowedFileSize = 2097152;
	var allowDirectLink = true;
	var deleteButton = true;

	$.getJSON( "configStorage.json", {_: new Date().getTime()}, function( data ) {
		maxAllowedFileSize = data.maxFileUploadAllow.length == 0 ? 2097152 : (data.maxFileUploadAllow*1024)*1024;
		if(parseInt(data.link) == 1){
			allowDirectLink = true;
		}else{
			allowDirectLink = false;
		}
		if(parseInt(data.delete) == 1){
			deleteButton = true;
		}else{
			deleteButton = false;
		}
	});

	var dataList = $('#dataList');
	
	$(window).on('hashchange', function(e){
		dataDraw();
	}).trigger('hashchange');
	
	$('#dataTable').tablesorter();

	$('#dataTable').on('click','.delete', function(data) {
		$.post("initialize.php",{'do':'delete', 'file':$(this).attr('data-file') }, function(response){
			if(response.success){
				dataDraw();
			}else{
				$('.errors').empty();
				$('.errors').append("<p>"+response.error.msg+"</p>");
				removeError(4000);
			}
		}, 'json');
	});

	$('.searchfolderdir').on('input', function(evt){
		evt.preventDefault();
		dataDraw($(this).val());
	});

	$('#mkdir').submit(function(e) {
		e.preventDefault();
		var hashval = decodeURIComponent(window.location.hash.substr(1));
		var directory = $(this).find('#dirname').val();
		if(directory.length > 0){
			$.post('?',{'do': 'mkdir', 'name': directory, 'file': hashval}, function(data){
				if(data.success){
					dataDraw();
					$('.popup').css('display', 'none');
	 				$('body').css('overflow', '');
				}else{
					alert(data.error.msg);
				}
			},'json');
		}else{
			alert('Folder name is empty!');
		}
		$(this).find('#dirname').val('');
	});

	$('#rename').submit(function(e) {
		e.preventDefault();
		var hashval = decodeURIComponent(window.location.hash.substr(1));
		if(hashval.length > 0){
			hashval = hashval+'/';
		}
		var directory = $(this).find('#dirname').val();
		var filePath = $(this).find('.fileName').val();
		if(directory.length > 0){
			$.post('?',{'do': 'rename', 'name': directory, 'file': hashval, 'filepath': filePath}, function(data){
				if(data.success){
					dataDraw();
					$('.popup').css('display', 'none');
	 				$('body').css('overflow', '');
				}else{
					alert(data.error.msg);
				}
			},'json');
		}else{
			alert('File/Folder name is empty!');
		}
		$(this).find('#dirname').val('');
	});

	$('#move').submit(function(e) {
		e.preventDefault();
		var hashval = decodeURIComponent(window.location.hash.substr(1));
		if(hashval.length > 0){
			hashval = hashval+'/';
		}
		var directory = $(this).find('#dirname').val();
		var filePath = $(this).find('.fileName').val();
		if(directory.length > 0){
			$.post('?',{'do': 'move', 'name': directory, 'file': hashval, 'filepath': filePath}, function(data){
				if(data.success){
					dataDraw();
					$('.popup').css('display', 'none');
	 				$('body').css('overflow', '');
				}else{
					alert(data.error.msg);
				}
			},'json');
		}else{
			alert('Move path name is required!');
		}
		$(this).find('#dirname').val('');
	});

	$('#copy').submit(function(e) {
		e.preventDefault();
		var hashval = decodeURIComponent(window.location.hash.substr(1));
		if(hashval.length > 0){
			hashval = hashval+'/';
		}
		var directory = $(this).find('#dirname').val();
		var filePath = $(this).find('.fileName').val();
		if(directory.length > 0){
			$.post('?',{'do': 'copy', 'name': directory, 'file': hashval, 'filepath': filePath}, function(data){
				if(data.success){
					dataDraw();
					$('.popup').css('display', 'none');
	 				$('body').css('overflow', '');
				}else{
					alert(data.error.msg);
				}
			},'json');
		}else{
			alert('Copy path name is required!');
		}
		$(this).find('#dirname').val('');
	});

	$('#file_drop_target').on('dragover',function(){
		$(this).addClass('drag_over');
	}).on('dragstop',function(){
		$(this).removeClass('drag_over');
	}).on('drop',function(e){
		e.preventDefault();
		$('.errors').empty();
		var files = e.originalEvent.dataTransfer.files;
		$.each(files,function(index ,file) {
			uploadFile(file);
		});
		$(this).removeClass('drag_over');
		$('.popup').css('display', 'none');
 		$('body').css('overflow', '');
 		$(this).find('input').val(null);
 		removeError(5000);
	});

	$('html').on('click', function(evt){
		// evt.stopImmediatePropagation();
		// evt.preventDefault();
		$('.contextMenu-container').css('display', 'none');
	});

	$('input[type=file]').change(function(e) {
		e.preventDefault();
		$('.errors').empty();

		$.each(this.files,function(index, file) {
			uploadFile(file);
		});
		$('.popup').css('display', 'none');
 		$('body').css('overflow', '');
 		$(this).val(null);
 		removeError(5000);
	});


	function uploadFile(file) {
		var folder = decodeURIComponent(window.location.hash.substr(1));
		if(file.size > maxAllowedFileSize) {
			$('.errors').append("<p>Selected file size is larger than "+(Math.round((maxAllowedFileSize/1024)/1024))+" MB!</p>");
		}else{
			var returnData = '';
			var formData = new FormData();
			formData.append('file_data', file);
			formData.append('file', folder);
			formData.append('do','upload');
			var xhr = new XMLHttpRequest();
			xhr.open('POST', 'initialize.php');
			xhr.onload = function() {
				if (xhr.readyState === xhr.DONE) {
			        if (xhr.status === 200) {
			        	dataDraw();
			        	xhr.response
			        	var dataRes = JSON.parse(xhr.response);
			        	if(dataRes.error.length > 0){
			        		$('.errors').append("<p>"+dataRes.error+"</p>");
			        	}
			        }
			    }
	    		
	  		};
		    xhr.send(formData);
		}
	}

	function dataDraw(searchVal = '') {
		var hashval = window.location.hash.substr(1);
		$.get('initialize.php?do=list&search='+searchVal+'&file='+ hashval,function(data) {
			dataList.empty();

			$('#breadcrumb').empty().html(renderBreadcrumbs(hashval)); //For folder tree

			if(data.success) {
				if(data.results.length > 0){
					$.each(data.results, function(index, val){
						dataList.append(renderFileRow(val));
					});
				}else{
					dataList.append('<tr><td class="empty" colspan="4">This folder is empty</td></tr>');
				}
			}else{
				alert(data.error.msg);
				var path = document.location.pathname;
				var directory = path.substring(path.indexOf('/'), path.lastIndexOf('/'));
				window.location.href = directory;
			}
			$('#dataTable').retablesort();
		},'json');
	}

	function renderFileRow(data) {

		var link = $('<a class="name" oncontextmenu="openMenuContext($(this))"/>')
			.attr('href', data.is_dir ? '#' + encodeURIComponent(data.path.replace('FileManager/', '')) : './'+ encodeURIComponent(data.path).replaceAll("%2F", "/"))
			.text(data.name);
		var menuArr = ["Rename", "Move", "Copy"];
        if (!data.is_dir && !allowDirectLink){
        	link.css({'text-decoration' : 'none', 'cursor' : 'pointer'});	
        }
        if(!data.is_dir){
        	var menuArr = ['Download', "Rename", "Move", "Copy"];
        }
        if(deleteButton){
        	menuArr.splice(1, 0, "Delete");
        }
        var createContextMenu = "<ul class='contextMenu-container' style='display: none;'>";
        $.each(menuArr, function(index, val){
        	if(val == 'Download'){
				createContextMenu += "<li><a class='download' href='?do=download&file="+encodeURIComponent(data.path).replaceAll("%2F", "/")+"'>"+val+"</a></li>";
			}else if(val == 'Delete'){
				createContextMenu += "<li><a class='delete' data-file='"+data.path.replace('FileManager/', '')+"' href='javascript:void(0)'>"+val+"</a></li>";
			}else{
				createContextMenu += "<li><a class='openMenuPopup' onclick='openPopUp(\""+$.trim(val).toLowerCase()+"\", \""+data.path+"\")' data-type='"+val.toLowerCase()+"' href='javascript:void(0)'>"+val+"</a></li>";
			}
		});
		createContextMenu += "</ul>";

		var fileRow = $('<tr />')
			.addClass(data.is_dir ? 'is_dir' : '')
			.append( $('<td class="first" />').append(link).append(createContextMenu) )
			.append( $('<td/>').html($('<span class="type" />').text(data.is_dir ? 'Folder' : 'File')) )
			.append( $('<td/>').attr('data-sort', data.is_dir ? -1 : data.size).html($('<span class="size" />').text(formatFileSize(data.size))) )
			.append( $('<td/>').attr('data-sort',data.mtime).text(formatTimestamp(data.mtime)) );
		
		return fileRow;
	}

	function renderBreadcrumbs(path) {
		var base = "", htmlData = $('<div/>').append( $('<a href="'+base+'">File Manager</a></div>') );
		var nextPrev = "";
		var pathes = path.split('%2F');
		$.each(pathes,function(k,v){
			if(v) {
				if(v.toLowerCase() !== 'filemanager'){
					if(k > 0){
						nextPrev = '<a href="#'+(base+v).replace('%2F'+v, '')+'" style="margin-right: 10px;font-size: 15px;background: #eff4f5;padding: 0px 6px;border-radius: 5px;"><< Back</a>';
					}else{
						nextPrev = '<a href="" style="margin-right: 10px;font-size: 15px;background: #eff4f5;padding: 0px 6px;border-radius: 5px;"><< Back</a>';
					}
					var v_as_text = decodeURIComponent(v);
					htmlData.append( $('<span/>').text(' › ') )
						.append( $('<a/>').attr('href','#'+base+v).text(v_as_text) );
					base += v + '%2F';
				}
			}
		});
		htmlData.prepend(nextPrev);
		return htmlData;
	}

	function formatTimestamp(unix_timestamp) {
		var m = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
		var d = new Date(unix_timestamp*1000);
		return [d.getDate() < 10 ? '0'+d.getDate(): d.getDate(),'/',m[d.getMonth()],"/",d.getFullYear(),"    ",
			((d.getHours() % 12 || 12) < 10 ? '0' : '')+(d.getHours() % 12 || 12),":",(d.getMinutes() < 10 ? '0' : '')+d.getMinutes(),
			" ",d.getHours() >= 12 ? 'PM' : 'AM'].join('');
	}

	function formatFileSize(bytes) {
		var s = ['bytes', 'KB','MB','GB','TB','PB','EB'];
		for(var pos = 0;bytes >= 1000; pos++,bytes /= 1024);
		var d = Math.round(bytes*10);
		return pos ? [parseInt(d/10),".",d%10," ",s[pos]].join('') : bytes + ' bytes';
	}

	function removeError(time = 4000) {
		setTimeout(function(){
			if($('.errors').find('p').length > 0){
				$('.errors').find('p').each(function(index){
					var p = $(this);
					setTimeout(function(){
						p.fadeOut('slow');
					}, time);
				});
			}
		}, 1500);
	}


});

function openMenuContext(ownObject){
 	event.preventDefault();
 	$('.contextMenu-container').css('display', 'none');
 	ownObject.closest('td').find('.contextMenu-container').css({'left': ownObject.width(), 'display': ''});
    return false;
}

function closeMenuContext(){
	event.preventDefault();
 	$('.contextMenu-container').css('display', 'none');
}

function openPopUp(type = '', filePath = '') {
	event.stopImmediatePropagation();
	if(type.length > 0){
		$('.popup').css('display', 'none');
		$('.'+type).css('display', 'block');
		$('body').css('overflow', 'hidden');
		closeMenuContext();
		if(filePath.length > 0){
			if($('.'+type).find('.fileName').length > 0){
				$('.'+type).find('.fileName').val(filePath);
			}
		}
	}
}

function closePopUp() {
 	$('.popup').css('display', 'none');
 	$('body').css('overflow', '');
}

